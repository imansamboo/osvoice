<?php
namespace Ssh\Command;

/**
 * Class ShellCommand
 * @package Ssh\CommandInterface
 */
interface ShellCommandInterface extends CommandInterface {}