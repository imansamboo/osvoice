<?php
namespace Ssh\Command;

/**
 * Class ShellCommand
 * @package Ssh\CommandInterface
 */
class ShellCommand extends Command implements ShellCommandInterface {}